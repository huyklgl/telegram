// Stores the data retrieved from the database at the initialization stage to be used across the app

module.exports = {};
