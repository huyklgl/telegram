/**
 * Stores all the created Notion pages for updating and retrieving purposes
 */
module.exports = [];
